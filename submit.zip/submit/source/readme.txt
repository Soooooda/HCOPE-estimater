Steps to run the code:

1. Launch the terminal to start jupyter notebook
2. Click on RLtest.ipynb
3. Run the cells one by one.

P.S. The first part is producing the polilcy parameters, and the last part is rewriting the code to test the implementation on cartpole.
*The candidate selection and safety test will take a long time.